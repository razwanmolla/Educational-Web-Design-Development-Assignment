<!-- Create a PHP script that takes in a string as input and returns the number of vowels in the 
string. Vowels are the letters "a", "e", "i", "o", and "u", regardless of case.
    Your script should:
    • Ignore any non-alphabetic characters in the input string
    • Treat upper- and lowercase letters as equivalent
    • Output the number of vowels as an integer
For example, given the input string "Hello, world!", the output should be 3. -->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
        function countVowels($str) {
            // Remove non-alphabetic characters and convert the string to lowercase
            $cleanedStr = preg_replace("/[^a-z]/i", '', strtolower($str));
        
            // Use a regular expression to count vowels
            $vowelCount = preg_match_all("/[aeiou]/i", $cleanedStr);
        
            return $vowelCount;
        }
        
        // Example usage:
        $inputString = "wow,What A nice car it is!";
        $vowelCount = countVowels($inputString);
        echo "Number of vowels in the string: " . $vowelCount;
        
    ?>
</body>
</html>