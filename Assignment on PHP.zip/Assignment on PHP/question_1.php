<!-- 1. You have been tasked with creating a simple web application that allows users to register and 
login to their accounts. The application should have the following functionality:
    a) User registration form with fields for username, email, and password.
    b) Passwords should be securely hashed before being stored in the database.
    c) Email addresses should be unique for each user.
    d) User login form with fields for email and password.
    e) Upon successful login, users should be directed to a dashboard page that displays their 
    username and a welcome message.
    f) Users should be able to logout from any page in the application. 
Using PHP, MySQL and HTML, create a functional web application that meets the above 
requirements. Make sure to include validation for form inputs and error messages for failed login 
attempts.-->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <!-- Add this in your HTML file within <head> tags -->
<style>
    body {
        max-width: 300px;
        margin: 0 auto;
        padding: 20px;
        background-color: whitesmoke;
        border: 1px solid #ccc;
        border-radius: 5px;
    }

    .container {
        display: block;
        width: 93%;
        padding: 10px;
        margin-bottom: 10px;
        border: 1px solid #ccc;
        border-radius: 5px;
    }

    .registration, .login {
        width: 93%;
        padding: 10px;
        background-color: #007bff;
        color: #fff;
        border: none;
        border-radius: 5px;
        cursor: pointer;
    }

    .registration, .login:hover {
        background-color: #0056b3;
    }
</style>

</head>
<body>
<div class="container">
   <div class="registration">   <!-- registration.html -->
        <form action="question_1.php" method="post">
        <input type="int" name="id" placeholder="Id" required>
        <input type="text" name="username" placeholder="Username" required>
        <input type="email" name="email" placeholder="Email" required>
        <input type="password" name="password" placeholder="Password" required>
        <button type="submit">Register</button>
        </form>
   </div>

    <div class="login">   <!-- login.html -->
        <form action="question_1.php" method="post">
            <input type="email" name="email" placeholder="Email" required>
            <input type="password" name="password" placeholder="Password" required>
            <button type="submit">Login</button>
        </form>
    </div>

</div>

<?php
// Database connection
$conn = new mysqli("localhost", "root", "", "university");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
//Registration
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'];
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);

    // Check for duplicate email
    $checkEmail = $conn->prepare("SELECT * FROM users WHERE email = ?");
    $checkEmail->bind_param("s", $email);
    $checkEmail->execute();
    $result = $checkEmail->get_result();

    if ($result->num_rows > 0) {
        echo "Email already in use.";
    } else {
        // Insert user data into the database
        $stmt = $conn->prepare("INSERT INTO users (id,username, email, password) VALUES (?, ?, ?,?)");
        $stmt->bind_param("ssss", $id, $username, $email, $password);
        $stmt->execute();
        echo "Registration successful.";
    }
}

//Login
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Retrieve user data from the database
    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if ($user && password_verify($password, $user['password'])) {
        // Start a session or implement authentication logic
        echo "Welcome, " . $user['username'];
    } else {
        echo "Login failed. Please check your email and password.";
    }
}

$conn->close();
?>



</body>
</html>