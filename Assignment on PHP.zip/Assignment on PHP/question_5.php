<!-- Create a PHP script that takes in two numbers as input and then calculates and displays the 
sum, difference, product, and quotient of those two numbers. -->

<!DOCTYPE html>
<html>
<head>
    <title>Calculator</title>
    <style>
         body {
        max-width: 300px;
        margin: 0 auto;
        padding: 20px;
        background-color: whitesmoke;
        border: 1px solid #ccc;
        border-radius: 5px;
    }
    </style>
</head>
<body>
    <h1>Simple Calculator</h1>
    <form method="post" action="question_5.php">
        <label for="num1">Number 1:</label>
        <input type="text" name="num1" required><br><br>

        <label for="num2">Number 2:</label>
        <input type="text" name="num2" required><br><br>

        <input type="submit" value="Calculate">
    </form>

    <?php
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        $num1 = $_POST["num1"];
        $num2 = $_POST["num2"];

        // Check if both inputs are numeric
        if (is_numeric($num1) && is_numeric($num2)) {
            // Calculate and display results
            echo "Sum: " . ($num1 + $num2) . "<br>";
            echo "Difference: " . ($num1 - $num2) . "<br>";
            echo "Product: " . ($num1 * $num2) . "<br>";
            
            if ($num2 != 0) {
                echo "Quotient: " . ($num1 / $num2) . "<br>";
            } else {
                echo "Division by zero is not allowed.<br>";
            }
        } else {
            echo "Please enter valid numeric values.<br>";
        }
    }
    ?>
</body>
</html>
