<!-- Suppose you have an array of integers called $numbers with the following values:
 $numbers = array(2, 4, 6, 8, 10); Write a PHP code to perform the following tasks:
    i. Print the first element of the array.
    ii. Print the last element of the array.
    iii. Add a new element with the value of 12 to the end of the array.
    iv. Calculate the sum of all the elements in the array and print the result -->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        body{
            max-width: 300px;
        margin: 0 auto;
        padding: 20px;
        background-color: whitesmoke;
        border: 1px solid #ccc;
        border-radius: 5px;
        }
    </style>
</head>
<body>
    <?php
        $numbers = array(2, 4, 6, 8, 10);

        // i. Print the first element of the array
        $firstElement = reset($numbers);
        echo "First element: $firstElement<br>";
        
        // ii. Print the last element of the array
        $lastElement = end($numbers);
        echo "Last element: $lastElement<br>";
        
        // iii. Add a new element with the value of 12 to the end of the array
        $numbers[] = 12;
        
        // iv. Calculate the sum of all the elements in the array and print the result
        $sum = array_sum($numbers);
        echo "Sum of all elements: $sum<br>";
        
    ?>
</body>
</html>