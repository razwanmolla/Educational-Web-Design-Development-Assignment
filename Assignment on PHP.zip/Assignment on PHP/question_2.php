<!-- Write a PHP function that takes an array of integers as an argument and returns the sum of all 
even numbers in the array. -->


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
        function sumEvenNumbers($arr) {
            $sum = 0;
        
            foreach ($arr as $number) {
                if ($number % 2 == 0) {
                    $sum += $number;
                }
            }
        
            return $sum;
        }
    
        // Example usage:
        $numbers = [1, 2, 3, 4, 5, 6, 7, 8];
        $result = sumEvenNumbers($numbers);
        echo "Sum of even numbers: " . $result;
    ?>    
</body>
</html>