<!DOCTYPE html>
<html>

<head>
    <title>User Registration</title>
    <!-- <link rel="stylesheet" href="form.css"> -->
</head>

<body>
    <h2>User Registration</h2>
    <form action="question_4.php" method="post">
        Name: <input type="text" name="name" required><br>
        Email: <input type="email" name="email" required><br>
        <input type="submit" value="Register">
    </form>

    <?php

$connection = mysqli_connect("localhost", "root", "", "university");


if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}


$name = $_POST['name'];
$email = $_POST['email'];


$sql = "INSERT INTO users (name, email) VALUES ('$name', '$email')";


if ($connection->query($sql) === TRUE) {
    echo "Registration successful. Your information has been saved.";
} else {
    echo "Error: " . $sql . "<br>" . $connection->error;
}


$connection->close();
?>
</body>

</html>